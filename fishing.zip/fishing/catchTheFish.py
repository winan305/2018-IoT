from Fish import Fish
from Fish import FISH_NUM, KINDS_NUM
import pygame
import os
import math

TARGET_FPS = 200

WIDTH = 1343
HEIGHT = 657

def drawMouseCircle(fish):
    mouseX, mouseY, mouseR = fish.getMouseLocation()
    pygame.draw.circle(screen, (255, 0, 0), (mouseX, mouseY), mouseR, 1)

# 잡혔는지 확인
def checkCatch(fishes, pos):
    # boolean 값 반환
    for nums in range(0, FISH_NUM):
        for kinds in range(0, KINDS_NUM):
            # 물고기의 입 좌표 = (x, y, radius)
            mouth = fishes[nums][kinds].getMouseLocation()
            # 물고기의 입 좌표와 마우스 사이의 거리가 1보다 작으면 잡힘
            if (math.sqrt((mouth[0]-pos[0])**2+(mouth[1]-pos[1])**2) <= mouth[2]):
                return (True,nums,kinds)
    return (False, -1, -1)

# 잡힌 물고기 리스트
catchedList = []
# 사라진 물고기는 10초 후에 다시 생성
def catchedFish(timer):
    if (len(catchedList) == 0):
        return 0
    timer += 1
    if (timer == TARGET_FPS*2):
        catchedList.pop(0)
        timer = 0
    return timer

catchingList = []
def fishRanAway():
    for f in catchingList:
        timer = f.catchEvent()
        screen.blit(pygame.transform.rotate(f.getImage(), -90), f.getRect())
        if (timer >= TARGET_FPS*2):
            f.initTime()
            catchingList.remove(f)
    return

def main():
    pygame.init()
    global screen
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    backgreound = pygame.image.load(os.getcwd()+'/images/background5.png')
    clock = pygame.time.Clock()
    timer = 0
    run = True
    # 음 이부분은 적당한 좋은 방법이 생각이 안나는군
    fishes = []
    fish1 = []
    fish2 = []
    fish3 = []
    # fish4 = []
    # fish5 = []
    for i in range(0,KINDS_NUM):
        fish1.append(Fish(i))
        fish2.append(Fish(i))
        fish3.append(Fish(i))
        #fish1.append(Fish(4))
        #fish1.append(Fish(5))
    fishes.append(fish1)
    fishes.append(fish2)
    fishes.append(fish3)
    # fishes.append(fish4)
    # fishes.append(fish5)
    for i in range(0,KINDS_NUM):
        fish1.append(Fish(i))
        fish2.append(Fish(i))
        fish3.append(Fish(i))

    while run:
        # 마우스 좌표 출력
#        clickMouseEvent(screen)
#         print("마우스: ",pygame.mouse.get_pos())
        screen.blit(backgreound,(0,0))

        # 움직임 # 객체 그림
        #작은 물고기
        for nums in range(0,FISH_NUM):
            for kinds in range(0,KINDS_NUM):
                state = False #T=잡힘, F=안잡힘
                # 잡힌 물고긴지 확인
                for catched in catchedList:
                    if (catched == fishes[nums][kinds]):
                        state = True
                if (state is True):
                    continue

                # 안잡힌 물고기만 blit
                if(fishes[nums][kinds].move(WIDTH,HEIGHT) is True):
                    screen.blit(fishes[nums][kinds].getImage(),fishes[nums][kinds].getRect())
                else:
                    screen.blit(pygame.transform.flip(fishes[nums][kinds].getImage(),True,False), fishes[nums][kinds].getRect())
                #drawMouseCircle(fishes[nums][kinds])
                check = fishes[nums][kinds].collide(fishes)
                # print(check)
                if (check):
                    fishes[nums][kinds].move(WIDTH, HEIGHT)

        fishRanAway()

        # 화면 전체 업데이트
        pygame.display.flip()

        # 초당 프레임 맞추기
        # TARGET_FPS: 목표로 하는 FPS
        clock.tick(TARGET_FPS)

        for event in pygame.event.get():
            # ESC 눌러서 종료
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    run = False
            # 마우스 왼쪽 버튼 클릭
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                pos = pygame.mouse.get_pos() # 마우스 좌표 받음
                # 마우스 좌표와 물고기 좌표가 일치하는지 확인 : (일치여부, nums, kinds)
                checked = checkCatch(fishes, pos)
                # 일치하는 경우
                if (checked[0] is True):
                    flag = False
                    for catched in catchedList:
                        # 잡힌 물고기는 리스트에 추가
                        if (catched == fishes[checked[1]][checked[2]]):
                            flag = True
                    if (flag is False):
                        # 잡힘
                        print("잡혔다: ", checked[1],checked[2])
                        catchedList.append(fishes[checked[1]][checked[2]])
                        catchingList.append(fishes[checked[1]][checked[2]])
        timer = catchedFish(timer)
    pygame.quit()

main()