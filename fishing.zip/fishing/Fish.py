from random import randint
import pygame
import os
import math

WIDTH = 1349        # 스크린 너비
HEIGHT = 657        # 스크린 높이
FISH_NUM = 3        # fish 묶음
KINDS_NUM = 5       # fish 종류
SPEED = 2           # 기본속도
RED = (255, 0, 0)   # 붉은색

# 물고기의 입 클래스
class Mouth:
    def __init__(self, index=1):
        # 물고기별 입 크기 스케일링
        if (index == 0):
            self._x = 0
            self._y = 30
        if(index == 1):
            self._x = 0
            self._y = 35
        if(index == 2):
            self._x = 15
            self._y = 40
        if(index == 3):
            self._x = 0
            self._y = 30
        if(index == 4):
            self._x = 0
            self._y = 40
        self._radius = 30

    def setPointX(self, x):
        self._x = x
    def getPointX(self):
        return self._x
    def getPointY(self):
        return self._y
    def getRadius(self):
        return self._radius

# 물고기 클래스
class Fish:
    def __init__(self, index=1):
    # 인덱스 받음 (디폴트 1)
    # 인덱스별로 이미지 다르고, 크기 다름
        fishList = []
        for i in range(1, 6):
            fishList.append(os.getcwd() + '/images/fish_' + str(i) + '.png')
        self.Mouth = Mouth(index)
        self.img = pygame.image.load(fishList[index])
        # 물고기별 크기 스케일링
        if (index == 0):
            self.img = pygame.transform.scale(self.img, (70, 60))
        if(index == 1):
            self.img = pygame.transform.scale(self.img, (100, 65))
        if(index == 2):
            self.img = pygame.transform.scale(self.img, (130, 90))
        if(index == 3):
            self.img = pygame.transform.scale(self.img, (70, 80))
        if(index == 4):
            self.img = pygame.transform.scale(self.img, (120, 80))
            self.img = pygame.transform.flip(self.img,True,False)
        self.speed = SPEED

        # 객체가 그려질 위치와 크기를 나타내는 pygame.Rect 객체
        self.rec = self.img.get_rect()
        # 물고기 생성 위치를 랜덤하게 생성
        self.rec.x = randint(0, WIDTH-self.rec.width)
        self.rec.y = randint(0, HEIGHT-self.rec.height)
        # 목표 좌표
        self._targetx = -1
        self._targety = -1
        # 잡힐때 남아있을 타이머
        self.timer = 0

    # 이미지 객체 반환
    def getImage(self):
        return self.img
    # Rect 객체 반환
    def getRect(self):
        return self.rec
    # rec 좌표 반환
    def getPoint(self):
        return self.rec.x, self.rec.y

    # 움직임 - 랜덤으로 목표 좌표 설정 후 이동, 목표좌표에 도달하면 새로운 값 설정
    def move(self, w, h):
        # y축 움직임
        if (self._targety-self.speed <= self.rec.y and self.rec.y <= self._targety+self.speed):
            # 현재-기본스피드<타겟 y 좌표<현재+기본스피드 => 타겟 y를 재설정 //스피드=움직임 크기
            self._targety = randint(0, h-self.rec.height)
        else:
            if (self.rec.y < self._targety): # 현재 < 타겟 속도만큼 이동
                self.rec.y += self.speed
            else:
                self.rec.y -= self.speed
        # x축 움직임
        if (self._targetx - self.speed <= self.rec.x and self.rec.x <= self._targetx + self.speed):
            # 현재-기본스피드<타겟 x 좌표<현재+기본스피드 => 타겟 x를 재설정
            self._targetx = randint(0, w-self.rec.width)
        else:
            if (self.rec.x < self._targetx): # 현재 < 타겟 속도만큼 이동
                self.rec.x += self.speed
                self.Mouth.setPointX(self.rec.width-5)
                return False
            else:
                self.rec.x -= self.speed
                self.Mouth.setPointX(5)
                return True

    # 물고기 입의 좌표 반환
    def getMouseLocation(self):
        _x = self.Mouth.getPointX() + self.rec.x
        _y = self.Mouth.getPointY() + self.rec.y
        _r = self.Mouth.getRadius()
        return _x, _y, _r

    # 물고기간의 거리 기반 충돌감지 함수
    def collide(self, fishes):
        movingPlease = False
        try:
            for fishs in range(0, FISH_NUM):
                for kinds in range(0, KINDS_NUM):
                    if (self is not fishes[fishs][kinds]):
                        dist = math.sqrt( (self.rec.x-fishes[fishs][kinds].rec.x)**2 + (self.rec.y-fishes[fishs][kinds].rec.y)**2 )
                        # 각 물고기간 거리가 100이하로 떨어지면 True값 반환 => 무브 재호출(2회 움직임으로, 빠르게 움직이는 것으로 보임)
                        if(dist<100):
                            movingPlease = True
                            return movingPlease
            return movingPlease
        except:
            print("except")

    # 낚이면 수직으로 이동
    def catchEvent(self):
        self.rec.y -= self.speed*3
        self.timer += 1
        return self.timer

    def initTime(self):
        self.timer = 0